/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

//#include "system.h"        /* System funct/params, like osc/peripheral config */
//#include "user.h"          /* User funct/params, such as InitApp */

#include <timers.h>
#include <pwm.h>
#include <delays.h>
#include <usart.h>
//#include <i2c.h>


#define ST_CHAR  0xFE
#define ESC_CHAR 0xFD
#define MSG_LEN  6

/******************************************************************************/
/* User Global Variable Declaration                                           */
/******************************************************************************/

void echoUsart(void);
void parseSerialMsg(void);
void paintLED(char* colors);
void storeColor(char* colors);
void getLastColor(char* color);

/******************************************************************************/
/* Main Program                                                               */
/******************************************************************************/

unsigned char ledDriverMsg[28];

unsigned char rxCounter = 0, escaped = 0, in_msg = 0,
        rxBuffer[MSG_LEN] = {0xFF, 0xFF, 0xFF, 0xFF, 0x00, 0x00};


void main(void) {
    char i,j;
    char pressed = 0;

    RCONbits.IPEN     = 1; // Enable interrupts priority
    INTCONbits.GIEH   = 1; // Enable High priority interrupts
    PIE1bits.RCIE     = 1; // Enable USART RX interrupt
    IPR1bits.RCIP     = 1; // High priority for RX intr

    // I2C or serial comm
    ADCON1bits.PCFG3 = 1;
    TRISB = 0x00;
    PORTB = 0x00;

    // PWM pins
    TRISC=0x00;
    PORTC=0xFF;

    // Button pin
    TRISD=0xFF;

    // UART config
    OpenUSART( USART_TX_INT_OFF &
        USART_RX_INT_ON &
        USART_ASYNCH_MODE &
        //USART_SYNC_MASTER &
        USART_EIGHT_BIT &
        USART_CONT_RX &
        USART_BRGH_HIGH,
        129 );


    /*OpenTimer0( TIMER_INT_ON &
                T0_8BIT &
                T0_SOURCE_INT &
                T0_PS_1_1 );*/


    for (i=27; i>3; i--) {
        ledDriverMsg[i] = 0x00;
    }

    ledDriverMsg[3] = 0xFF;
    ledDriverMsg[2] = 0xFF;
    ledDriverMsg[1] = 0b11011111; //
    ledDriverMsg[0] = 0b10010110; //0x96

    //getLastColor(&rxBuffer);
    paintLED(&rxBuffer);

    while(1) {
        if (!PORTDbits.RD2) {
            while(!PORTDbits.RD2);
            putrsUSART("Pressed");
        }
    }
}

void echoUsart(void) {
    static unsigned char data;

    if (DataRdyUSART())
        data = getcUSART();

    while(BusyUSART());
    putcUSART(data);
}

void parseSerialMsg(void) {
    static unsigned char byte, status;

    if (DataRdyUSART()) {
        byte = getcUSART();

        if ( (!in_msg) && (byte != ST_CHAR) ) {
            status = 'n';
            in_msg = 0;

        } else if ( byte == ST_CHAR ) {

            if (escaped) {
                status = 'd';

                rxBuffer[rxCounter++] = byte;
                escaped = 0;
            } else {
                status = 's';

                rxCounter = 0;
                in_msg = 1;
                escaped = 0;
            }
        } else if ( byte == ESC_CHAR ) {
            if (escaped) {
                status = 'd';

                rxBuffer[rxCounter++] = byte;
                escaped = 0;
            } else {
                status = 'e';

                escaped = 1;
            }

        } else {
            status = 'd';

            rxBuffer[rxCounter++] = byte;
            escaped = 0;

        }

        if ( rxCounter == MSG_LEN ) {
            status = 'k';

            rxCounter = 0;
            escaped = 0;
            in_msg = 0;
            //storeColor(rxBuffer);
            paintLED(rxBuffer);
        }

        while(BusyUSART());
        putcUSART(status);
    }
}

void getLastColor(char* color) {
    static char i;

    for (i=0; i<6; i++) {
        EECON1 = 0x00;

        EEADR = i;

        EECON1bits.RD = 1;

        color[i] = EEDATA;
    }
}

void storeColor(char* colors) {
    static char i;

    //INTCONbits.GIE = 0;

    for (i=0; i<6; i++) {
        EEADR = i;
        EEDATA= colors[i];

        //EECON1 = 0x04;
        EECON1bits.EEPGD = 0;
        EECON1bits.CFGS = 0;
        EECON1bits.WREN = 1;

        EECON2 = 0x55;
        EECON2 = 0xAA;

        EECON1bits.WR = 1;
        while(!PIR2bits.EEIF);
        PIR2bits.EEIF = 0;
    }

    EECON1bits.WREN = 0;
    //INTCONbits.GIE = 1;
}

void paintLED(char* colors) {
    static unsigned char i,j;

    for (i=0; i<6; i++) {
        ledDriverMsg[27-i] = colors[i];
    }

    PORTBbits.RB1 = 1;
    for(i=0; i<28; i++) {
        for(j=8; j>0; j--){
            PORTBbits.RB1 = 0;
            PORTBbits.RB0 = ( ledDriverMsg[i]>>(j-1) ) & 0x01;
            PORTBbits.RB1 = 1;
        }
    }
    PORTBbits.RB0 = 0;
    PORTBbits.RB1 = 0;
}
