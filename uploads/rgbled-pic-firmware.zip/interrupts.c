#include <p18f4550.h>

/******************************************************************************/
/* Interrupt Routines                                                         */
/******************************************************************************/
void highISR(void);

#pragma code HIGH_INTERRUPT_VECTOR = 0x8
/* High-priority service */
void high_ISR(void) {
    _asm
        goto highISR
    _endasm
}
#pragma code

#pragma interrupt highISR
/* High-priority service */
void highISR(void) {

    if(PIR1bits.RCIF) {
        PIE1bits.RCIE = 0;

        // Real function to execute
        parseSerialMsg();

        // Clear Interrupt Flag
        PIR1bits.RCIF = 0;
        PIE1bits.RCIE = 1;
    }
}
